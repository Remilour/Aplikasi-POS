<?php

    $koneksi = mysqli_connect('localhost', 'root', '', 'db_tokoonline');

    //cek koneksi
    if (mysqli_connect_errno()) { //cek apakah koneksi error, menampilkan pesan
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        exit();
    }

?>