<?php

    require "koneksi.php";
    $queryProduk = mysqli_query($koneksi, "SELECT id, nama, harga, foto, detail FROM produk LIMIT 6");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dear's Fashion | Home</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php require "navbar.php"; ?>

    <!-- banner -->
    <div class="container-fluid banner d-flex align-items-center">
        <div class="container text-center text-white">
                <h1>DEAR's FASHION</h1>
                <h3>Welcome to Our Website!</h3>
                <form method="get" action="produk.php">
                <div class="col-md-8 offset-md-2">
                    <div class="input-group input-group-lg my-4">
                        <input type="text" class="form-control" placeholder="Cari produk yang anda inginkan" 
                        aria-label="Recipient's username" aria-describedby="basic-addon2" name="keyword">
                        <button type="submit" class="btn warna4 text-white">Search</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- highlited kategori -->
        <div class="container-fluid py-5">
            <div class="container text-center">
                <h3>Rekomendasi Untuk Anda</h3>
                <div class="row mt-5">
                    <div class="col-md-4 mb-3">
                        <div class="highlighted-kategori kategori-gelang"></div>
                            <h4 class="mt-4"><a href="produk.php?kategori=aksesoris" class="text-deco">Gelang Manik</a></h4>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="highlighted-kategori kategori-jepitan"></div>
                            <h4 class="mt-4"><a href="produk.php?kategori=aksesoris" class="text-deco">Jepit Rambut Kupu-Kupu</a></h4>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="highlighted-kategori kategori-cincin"></div>
                            <h4 class="mt-4"><a href="produk.php?kategori=aksesoris" class="text-deco">Cincin Manik Berlian</a></h4>
                    </div>
                </div>
            </div>
        </div>

        <!-- about us -->
        <div class="container-fluid warna3 py-5">
            <div class="container text-center text-white">
                <h3>About Us</h3>
                <p class="fs-5 mt-3">As a fashion store committed to providing a unique and satisfying shopping experience, have a rich background rooted in dedication to the fashion industry. Born from a passion to explore the latest trends and inspire modern lifestyles, our fashion store was founded with a vision to become the ultimate destination for those seeking style and quality. With an experienced team in the fashion industry, we continuously innovate in design, production, and product curation to ensure that each collection reflects the beauty and diversity of styles. We believe that fashion is not just about clothing but also about self-expression and confidence. Through a combination of friendly customer service and a selection of quality products, we strive to build lasting relationships with our customers, making our fashion store a favorite destination for fashion enthusiasts seeking a meaningful shopping experience.</p>
            </div>
        </div>

        <!-- produk -->
        <div class="container-fluid py-5">
            <div class="container text-center">
                <h3>Produk</h3>

                <div class="row mt-4">
                    <?php while($data = mysqli_fetch_array($queryProduk)) { ?>
                    <div class="col-sm-6 col-md-4 mb-3">
                        <div class="card h-100">
                            <img src="image/<?php echo $data['foto']; ?>" class="card-img-top" alt="...">
                              <div class="card-body">
                                <h5 class="card-title"><?php echo $data['nama']; ?></h5>
                                <p class="card-text text-truncate"><?php echo $data['detail']; ?></p>
                                <p class="card-text text-harga">Rp. <?php echo $data['harga']; ?></p>
                                <a href="produk-detail.php?nama=<?php echo $data['nama']; ?>" class="btn warna4 text-white">Lihat Detail</a>
                            </div>
                        </div>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>

        <!-- footer -->
        <?php
        
            require "footer.php";

        ?>

    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="fontawesome/js/all.min.js"></script>
</body>
</html>