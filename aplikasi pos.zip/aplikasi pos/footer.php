<div class="container-fluid warna4 py-3 text-light">
        <div class="container">

        <h5 class="text-center mb-1">Temui Kami</h5>
        <h5 class="text-center mt-5 mb-0">Subscribe</h5>
                 <p class="text-center font-monospace mt-4">Untuk informasi tentang promo</p>
                 <div class="col-md-8 offset-md-2 col-lg-6 offset-lg-3">
                     <div class="inpur-group mb-3">
                         <input type="text" class="form-control" placeholder="Masukkan Email" aria-label="Recipient's username" 
                         aria-describedby="button-addon2">
                         <button class="btn btn-warning text-light mt-2" type="button" id="button-addon2">Subscribe</button>
                     </div>
                 </div>

                <div class="row justify-content-center">
                    <div class="col-sm-1 d-flex justify-content-center mb-2">
                        <i class="fab fa-facebook fs-4"></i>
                    </div>
                    <div class="col-sm-1 d-flex justify-content-center mb-2">
                        <i class="fab fa-instagram fs-4"></i>
                    </div>
                    <div class="col-sm-1 d-flex justify-content-center mb-2">
                        <i class="fab fa-twitter fs-4"></i>
                    </div>
                    <div class="col-sm-1 d-flex justify-content-center mb-2">
                        <i class="fab fa-youtube fs-4"></i>
                    </div>
                </div>
            </div>
    </div>
</div>

<div class="container-fluid py-3 bg-dark text-light">
    <div class="container d-flex justify-content-between">
        <label>&copy; 2023 DEAR's Fashion</label>
        <label>Created by Nakama Team</label>
    </div>
</div>

<script src="bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="fontawesome/js/all.min.js"></script>