<nav class="navbar navbar-expand-lg navbar-dark warna1">
         <div class="container">
           <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
             <span class="navbar-toggler-icon"></span>
           </button>
           <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
             <ul class="navbar-nav me-auto mb-2 mb-lg-0">
               <li class="nav-item me-4">
                    <a class="nav-link" href="../adminpanel">Home</a>
               </li>
               <li class="nav-item me-4">
                     <a class="nav-link" href="kategori.php">Kategori</a>
               </li>
               <li class="nav-item me-4">
                     <a class="nav-link" href="produk.php">Produk</a>
               </li>
             </ul>
           </div>
         </div>
</nav>